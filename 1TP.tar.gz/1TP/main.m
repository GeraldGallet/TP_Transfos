# Fichier principal
exo_ca();
exo_cb();