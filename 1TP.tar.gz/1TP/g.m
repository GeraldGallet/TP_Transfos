function[x] = g(t)
  x = 3 * exp(-4*(t - 1).^2) + 2 * exp(-2*(t - 2.5).^2);
end  