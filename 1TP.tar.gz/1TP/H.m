function[x] = H(t)
  x = t >= 0;
end