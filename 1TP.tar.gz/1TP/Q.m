function[x] = Q(t)
  x = (t >= -1) .* (t <= 1); 
end