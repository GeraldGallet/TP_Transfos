function[x] = f(t)
  x = 2*H(t) .* exp(-t);
end