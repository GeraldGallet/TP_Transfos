function[x] = P(t)
  x = (t >= -1/2) .* (t <= 1/2);
end